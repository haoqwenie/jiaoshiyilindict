local hide_words =
{ 	["示~例~"] = { "shil", "shili", },
}
return hide_words